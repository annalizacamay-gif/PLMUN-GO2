package com.example.plmungo

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener

class MainActivity : AppCompatActivity() {

    private lateinit var mapImage: ImageView

    private val roomsByFloor = mapOf(
        "Ground" to arrayOf("Admin Office", "Registrar", "Accounting", "Guidance Office", "Main Lobby", "Security Gate"),
        "2nd" to arrayOf("Room 201 - CTE Faculty", "Room 202 - CAS Classroom", "Room 203 - Education Lab", "Room 204 - English Dept", "Room 205 - Math Dept"),
        "3rd" to arrayOf("Room 301 - Computer Lab 1", "Room 302 - Computer Lab 2", "Room 303 - Science Lab", "Room 304 - Research Office", "Room 305 - CTE Dean Office"),
        "4th" to arrayOf("Room 401 - Main Library", "Room 402 - E-Library", "Room 403 - Reading Area", "Room 404 - Library Office"),
        "5th" to arrayOf("Room 501 - CTE 501", "Room 502 - CTE 502", "Room 503 - CTE 503", "Room 504 - CAS Faculty", "Room 505 - Conference Hall")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mapImage = findViewById(R.id.mapImage)
        val searchBar = findViewById<EditText>(R.id.searchBar)

        val btnGround = findViewById<Button>(R.id.btnGround)
        val btnSecond = findViewById<Button>(R.id.btnSecond)
        val btnThird = findViewById<Button>(R.id.btnThird)
        val btnFourth = findViewById<Button>(R.id.btnFourth)
        val btnFifth = findViewById<Button>(R.id.btnFifth)

        val menuDirectory = findViewById<TextView>(R.id.menuDirectory)
        val menuInfo = findViewById<TextView>(R.id.menuInfo)
        val menuFloor = findViewById<TextView>(R.id.menuFloor)

        fun showRooms(floorName: String, imageRes: Int) {
            mapImage.setImageResource(imageRes)
            val rooms = roomsByFloor[floorName]?: arrayOf("No rooms")

            AlertDialog.Builder(this)
                .setTitle("$floorName Floor - Rooms")
                .setItems(rooms) { _, which ->
                    val selectedRoom = rooms[which]
                    Toast.makeText(this, "📍 $selectedRoom is on $floorName Floor!", Toast.LENGTH_LONG).show()
                }
                .setPositiveButton("Close", null)
                .setNegativeButton("Emergency Exit") { _, _ ->
                    AlertDialog.Builder(this)
                        .setTitle("Emergency Exit - $floorName")
                        .setMessage("From $floorName Floor:\n1. Hanapin RED EXIT sign\n2. Stairwell near Elevator\n3. Baba to Ground\n4. Labas sa Gate / Oval")
                        .setPositiveButton("OK", null)
                        .show()
                }
                .show()
        }

        btnGround.setOnClickListener { showRooms("Ground", R.drawable.campus_ground) }
        btnSecond.setOnClickListener { showRooms("2nd", R.drawable.second) }
        btnThird.setOnClickListener { showRooms("3rd", R.drawable.third) }
        btnFourth.setOnClickListener { showRooms("4th", R.drawable.fourth) }
        btnFifth.setOnClickListener { showRooms("5th", R.drawable.fifth) }

        searchBar.addTextChangedListener { text ->
            val query = text.toString().lowercase()
            when {
                query.contains("ground") || query.contains("admin") -> mapImage.setImageResource(R.drawable.campus_ground)
                query.contains("2nd") || query.contains("201") -> mapImage.setImageResource(R.drawable.second)
                query.contains("3rd") || query.contains("301") -> mapImage.setImageResource(R.drawable.third)
                query.contains("4th") || query.contains("library") || query.contains("401") -> mapImage.setImageResource(R.drawable.fourth)
                query.contains("5th") || query.contains("501") -> mapImage.setImageResource(R.drawable.fifth)
            }
        }

        menuDirectory.setOnClickListener {
            val floors = arrayOf("Ground Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor")
            AlertDialog.Builder(this)
                .setTitle("Select Floor")
                .setItems(floors) { _, which ->
                    val floorKey = listOf("Ground","2nd","3rd","4th","5th")[which]
                    val imageRes = listOf(R.drawable.campus_ground, R.drawable.second, R.drawable.third, R.drawable.fourth, R.drawable.fifth)[which]
                    showRooms(floorKey, imageRes)
                }
                .show()
        }

        menuInfo.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("PLMUN GO - How to Use")
                .setMessage("1. Click FLOOR buttons (Ground-5th)\n2. Lalabas list ng ROOMS\n3. Click room para malaman location\n4. SEARCH room number\n\nGround-5th Floor lang ang PLMUN!")
                .setPositiveButton("Gets!", null)
                .show()
        }

        menuFloor.setOnClickListener {
            val floors = arrayOf("Ground Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor", "Emergency Exit Guide")
            AlertDialog.Builder(this)
                .setTitle("Floor Plans")
                .setItems(floors) { _, which ->
                    if(which == 5) {
                        AlertDialog.Builder(this)
                            .setTitle("Emergency Exit")
                            .setMessage("1. Stay calm\n2. RED signs to stairwell\n3. Baba to Ground\n4. Labas sa Gate")
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        val floorKey = listOf("Ground","2nd","3rd","4th","5th")[which]
                        val imageRes = listOf(R.drawable.campus_ground, R.drawable.second, R.drawable.third, R.drawable.fourth, R.drawable.fifth)[which]
                        showRooms(floorKey, imageRes)
                    }
                }
                .show()
        }
    }
}